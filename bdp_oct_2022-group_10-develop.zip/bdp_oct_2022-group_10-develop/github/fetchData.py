import requests
import os
import json
import time
from urllib.parse import urlencode

# Relative directory path of project
rel_directory = os.getcwd() + '/github/data'

# # Base url of github api
base_url = 'https://api.github.com/search/users'
access_token = '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'
headers = {'Authorization': f'token {access_token}'}


def begin_coroutine(func):
    def wrapper_function(*args, **kwargs):
        result = func(*args, **kwargs)
        result.__next__()
        return result
    return wrapper_function


@begin_coroutine
def fetch_data_from_github(next_stage):
    while True:
        index = yield
        params = {
            'page': index,
            'per_page': '100',
            'sort': 'followers',
            'order': 'desc'
        }
        print(f'Sending request of {index} params is: {params}')
        response = requests.get(base_url+'?'+urlencode(params)+f'&q=type:user+repos:%3E10+followers:%3E1000', headers=headers)
        if response.status_code == 200:
            jsonResponseData = response.json()
            if index==1:
                print(f'Total count request has {jsonResponseData["total_count"]}')
            if 'items' in jsonResponseData:
                usersList = jsonResponseData['items']
                userProfiles = []
                for user in usersList:
                    userProfileUrl = user['url']
                    userProfileResponse = requests.get(userProfileUrl, headers=headers)
                    if userProfileResponse.status_code == 200:
                        userProfile = userProfileResponse.json()
                        if 'score' in user:
                            userProfile['score'] = user['score']
                        userProfiles.append(userProfile)
                data = {
                    'index': index,
                    'jsonData': userProfiles
                }
                next_stage.send(data)
        else:
            print(f'Error response Status code: {response.status_code}')
            print(f'Response content: {response.content}')


@begin_coroutine
def write_data_to_file():
    while True:
        data = yield
        with open(f'{rel_directory}/github-{data["index"]}.json', 'w', encoding='utf-8') as f:
            json.dump(data["jsonData"], f, ensure_ascii=False, indent=4)


def pipeline_starter(next_stage):
    # Number of requests that will be send to github api, each request will get 100 users data per request
    rangeLimit = 10  # Only the first 1000 search results are available
    print(f'Sending {rangeLimit} requests to github API')
    print(f" started at {time.strftime('%X')}")
    for index in range(1, rangeLimit+1):
        next_stage.send(index)

    print(f" ended at {time.strftime('%X')}")


pipeline_starter(fetch_data_from_github(write_data_to_file()))
