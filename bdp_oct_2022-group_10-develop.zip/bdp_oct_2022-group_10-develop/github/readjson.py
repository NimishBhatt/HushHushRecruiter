import json
# import csv # Open the JSON file and load the data
import pandas as pd

resultData = []

def readJson(file):
    with open(file, 'r', encoding='utf-8') as f:
        jsonData = json.load(f)
        for eachUser in jsonData:
            tempData = {}
            tempData['user_id'] = eachUser['id']
            tempData['username'] = eachUser['login']
            tempData['email'] = eachUser['email']
            tempData['achievements'] = eachUser['public_gists']
            tempData['repos'] = eachUser['public_repos']
            tempData['Gold'] = 0
            tempData['Silver'] = 0
            tempData['Bronze'] = 0
            resultData.append(tempData)

def start_reading():
    rangeLimit = 10
    for index in range(1, rangeLimit+1):
        readJson(f'github/data/github-{index}.json')

    df = pd.DataFrame(resultData)
    df.to_csv('github/GithubMergedUserData.csv', index=False)

start_reading()

