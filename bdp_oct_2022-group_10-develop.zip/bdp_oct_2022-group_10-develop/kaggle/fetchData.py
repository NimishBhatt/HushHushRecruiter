import pandas as pd

user_achievements_df = pd.read_csv('kaggle/data/UserAchievements.csv')

user_df = pd.read_csv('kaggle/data/Users.csv')

merged_df = pd.merge(user_df, user_achievements_df, left_on='Id', right_on = 'UserId')
print(merged_df)

merged_df.to_csv('kaggle/data/KaggleMergedUserData.csv', index=False)
