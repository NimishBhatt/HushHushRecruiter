# import libraries
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LinearRegression
# pip install pywin32
from win32com import client as win32

def hushHush():
    # read in the three CSV files
    fileKaggle = pd.read_csv("kaggle/data/KaggleMergedUserData.csv")
    fileStack = pd.read_csv("stackoverflow/StackoverflowMergedUserData.csv")
    fileGithub = pd.read_csv("github/GithubMergedUserData.csv")

    # Group different types for a single user in Kaggle Data
    fileKaggle = fileKaggle.groupby("UserId").agg({"UserId": "first", "DisplayName": "first", "Points": "sum","Tier": "sum", "TotalGold": "sum","TotalSilver": "sum","TotalBronze": "sum"})

    # filter files based on certain column parameters
    fileKaggle = fileKaggle[fileKaggle["Tier"] >= 8 & fileKaggle["Points"]]
    fileStack = fileStack[fileStack["accept_rate"] > 80]
    fileGithub = fileGithub[fileGithub["repos"] > 5]

    # add prefix to user id column
    fileKaggle["UserId"] = "k" + fileKaggle["UserId"].astype(str)
    fileStack["user_id"] = "s" + fileStack["user_id"].astype(str)
    fileGithub["user_id"] = "g" + fileGithub["user_id"].astype(str)

    # Add an "email" column to fileKaggle and fileStack, filling it in with the username + a domain
    fileKaggle["email"] = fileKaggle["DisplayName"] + "@fakeemail.com"
    fileStack["email"] = fileStack["display_name"] + "@fakeemail.com"

    # Define a function to fill in missing email addresses using the "username" column
    def fill_missing_email(row):
        if pd.isna(row["email"]):
            return row["username"] + "@fakeemail.com"
        else:
            return row["email"]

    # Apply the function to the "email" column of fileGithub
    fileGithub["email"] = fileGithub.apply(fill_missing_email, axis=1)

    # select the columns you need from each file
    fileKaggle = fileKaggle[["UserId", "DisplayName", "email", "Points", "TotalGold","TotalSilver","TotalBronze"]] 
    fileStack = fileStack[["user_id", "display_name", "email", "reputation", "badge_counts_gold", "badge_counts_silver", "badge_counts_bronze"]] 
    fileGithub = fileGithub[["user_id", "username", "email", "achievements", "Gold", "Silver", "Bronze"]] 

    # rename columns
    fileKaggle.columns = ["User ID", "User Name", "Email", "Reputation", "Gold", "Silver", "Bronze"]
    fileStack.columns = ["User ID", "User Name", "Email", "Reputation", "Gold", "Silver", "Bronze"]
    fileGithub.columns = ["User ID", "User Name", "Email", "Reputation", "Gold", "Silver", "Bronze"]

    # drop the columns with "0" reputation
    fileKaggle = fileKaggle[fileKaggle["Reputation"] != 0]
    fileStack = fileStack[fileStack["Reputation"] != 0]
    fileGithub = fileGithub[fileGithub["Reputation"] != 0]

    # assign weights to Points
    fileKaggle["Gold Points"] = fileKaggle["Gold"] * 10
    fileKaggle["Silver Points"] = fileKaggle["Silver"] * 5
    fileKaggle["Bronze Points"] = fileKaggle["Bronze"]

    fileStack["Gold Points"] = fileStack["Gold"] * 10
    fileStack["Silver Points"] = fileStack["Silver"] * 5
    fileStack["Bronze Points"] = fileStack["Bronze"]

    fileGithub["Gold Points"] = fileGithub["Gold"] * 10
    fileGithub["Silver Points"] = fileGithub["Silver"] * 5
    fileGithub["Bronze Points"] = fileGithub["Bronze"]


    # calculate total points
    fileKaggle["Total Points"] = fileKaggle["Gold Points"] + fileKaggle["Silver Points"] + fileKaggle["Bronze Points"]
    fileStack["Total Points"] = fileStack["Gold Points"] + fileStack["Silver Points"] + fileStack["Bronze Points"]
    fileGithub["Total Points"] = fileGithub["Gold Points"] + fileGithub["Silver Points"] + fileGithub["Bronze Points"]

    # create a scaler object
    scaler = MinMaxScaler()

    # normalize Total Points and Reputation columns in fileKaggle
    fileKaggle[["Total Points"]] = scaler.fit_transform(fileKaggle[["Total Points"]])
    fileKaggle[["Reputation"]] = scaler.fit_transform(fileKaggle[["Reputation"]])

    # normalize Total Points and Reputation columns in fileStack
    fileStack[["Total Points"]] = scaler.fit_transform(fileStack[["Total Points"]])
    fileStack[["Reputation"]] = scaler.fit_transform(fileStack[["Reputation"]])

    # Normalize Reputation columns in fileGithub
    fileGithub[["Reputation"]] = scaler.fit_transform(fileGithub[["Reputation"]])

    # dropping the "Gold", "Silver" and "Bronze" columns from the data frame

    fileKaggle = fileKaggle[["User ID", "User Name", "Email", "Reputation", "Total Points"]]
    fileStack = fileStack[["User ID", "User Name", "Email", "Reputation", "Total Points"]]
    fileGithub = fileGithub[["User ID", "User Name", "Email", "Reputation", "Total Points"]]

    # append the two files after one another
    mergeks = pd.concat([fileKaggle, fileStack], axis=0)

    # assigning variables for regression

    inputValue = mergeks[["Reputation"]]
    targetValue = mergeks[["Total Points"]]

    # applying regression

    reg = LinearRegression()
    reg.fit(inputValue, targetValue)

    # predicting the 

    fileGithub["Total Points"] = reg.predict(fileGithub[["Reputation"]])

    # append the three files after one another
    appended_file = pd.concat([mergeks, fileGithub], axis=0)

    # reset the index of the appended file
    appended_file = appended_file.reset_index(drop=True)

    # print(appended_file)

    # Calculate the sum of the two columns
    appended_file["Final Score"] = appended_file["Reputation"] + appended_file["Total Points"]

    # Calculate the 99th percentile of the sum column
    threshold = appended_file["Final Score"].quantile(0.99)

    # Filter the DataFrame to only include rows where the sum is above the threshold
    df_above_threshold = appended_file[appended_file["Final Score"] > threshold]

    # Print the resulting DataFrame
    print(df_above_threshold)
    # saving the final file as a CSV
    df_above_threshold.to_csv("FinalScore.csv", index=False)

    sendEmails(df_above_threshold)

    # separate data based on suffixes
    # df_k = df_above_threshold[df_above_threshold['User ID'].str.startswith('k')]
    # df_s = df_above_threshold[df_above_threshold['User ID'].str.startswith('s')]
    # df_g = df_above_threshold[df_above_threshold['User ID'].str.startswith('g')]

    # create scatter plot
    # plt.scatter(df_k["Reputation"], df_k["Total Points"], c='red', label='k')
    # plt.scatter(df_s["Reputation"], df_s["Total Points"], c='green', label='s')
    # plt.scatter(df_g["Reputation"], df_g["Total Points"], c='blue', label='g')

    # # set plot title and labels
    # plt.title('Scatter plot with different colors')
    # plt.xlabel("Reputation")
    # plt.ylabel("Total Points")
    # plt.legend()

    # # display plot
    # plt.show()

def sendEmails(df):
    print(df)
    ownEmails = ['11018624@STUD.HOCHSCHULE-HEIDELBERG.DE', 
              '11018694@STUD.HOCHSCHULE-HEIDELBERG.DE',
              '11018580@STUD.HOCHSCHULE-HEIDELBERG.DE',
              '11018545@STUD.HOCHSCHULE-HEIDELBERG.DE']
    users = []
    emails = []

    # Iterate over columns using DataFrame.iteritems()
    for (colname,colval) in df.iteritems():
        if(colname =='UserName'):
            users = colval.values

        if(colname =='Email'):
            emails = colval.values

    # print(users)
    # print(emails)
    # for eachUser in users:
    #     outlook = win32.Dispatch('outlook.application')
    #     mail = outlook.CreateItem(0)
    #     message_template = f'''Dear {eachUser['name']},

    #     Your profile is selected for Coding Exam. Please follow the below link for the test.
        
    #     https://forms.gle/SUHS3peVyrV5Uv2E6core

    #     Regards,
    #     HushHush Recruting Team
    #     SRH Heidelberg'''
    #     mail.To = eachUser['email']
    #     mail.Subject = 'TestMail : You are selected for Hush Hush coding exam from SRH'
    #     mail.Body = message_template
    #     mail.Send()

    for email_address in ownEmails:
        
        outlook = win32.Dispatch('outlook.application')
        mail = outlook.CreateItem(0)
        allEmails = ";".join(emails)
        message_template = f'''Dear {email_address},

        This is email is intend to be send to following users emails:
        {allEmails}
        
        https://forms.gle/SUHS3peVyrV5Uv2E6core

        Regards,
        HushHush Recruting Team
        SRH Heidelberg'''
        mail.To = email_address
        mail.Subject = 'TestMail : You are selected for Hush Hush coding exam from SRH'
        mail.Body = message_template
        mail.Send()
    
final_df = pd.read_csv('FinalScore.csv')
sendEmails(final_df)